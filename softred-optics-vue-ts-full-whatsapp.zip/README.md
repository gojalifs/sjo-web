# SoftRed Optics — Vue 3 + TS + Vite + Tailwind (Animations + Parallax + Scroll-To-Top + WhatsApp)

## Jalankan
```bash
npm i
npm run dev
```

## Fitur
- Animasi **reveal on scroll** (directive `v-reveal`)
- **Parallax vertikal** di hero image & accent blob
- **Parallax horizontal** di banner **#promo**
- Tombol **Scroll-To-Top** (fade-in)
- **WhatsApp floating button** (default `6281234567890`) + CTA Chat di section Konsultasi
- Background putih

Ubah nomor & pesan WhatsApp di `src/App.vue`:
```ts
const whatsappNumber = '6281234567890'
const whatsappMessage = 'Halo SoftRed Optics! Saya mau tanya ketersediaan frame.'
```